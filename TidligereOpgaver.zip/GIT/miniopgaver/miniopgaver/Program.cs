﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Miniopgaver
{
    class Program
    {
        static void Main(string[] args)
        {
            //Opgave1();
            //Opgave2();
            //Opgave3();
            Opgave4();
            Opgave5();
        }

        static void Opgave1()
        // Create a program to print "hello" on screen and then print your name (In separate line)
        {
            Console.WriteLine("Opgave1:");
            Console.WriteLine("Hello");
            Console.WriteLine("Frank Sidor");
            Console.ReadKey();
            Console.WriteLine("");
        }

        static void Opgave2()
        // Write a program to print the result of adding 12 and 13 on screen
        {
            Console.WriteLine("Opgave2:");
            Console.WriteLine("12 + 13 = " + (12 + 13));
            Console.ReadKey();
            Console.WriteLine("");
        }

        static void Opgave3()
        // Write a program to print the result of dividing 24 into 5 on screen
        {
            Console.WriteLine("Opgave3:");
            Console.WriteLine("24 / 13 = {0}", 24/5f);
            Console.ReadKey();
            Console.WriteLine("");
        }

        static void Opgave4()
        // Write a program to print the result of the following operations:
        //  -1 + 3 * 5
        //  (24+5) % 7
        //  15 + -4 * 6 / 11
        //  2 + 10 / 6 * 1 - 7 % 2
        {
            Console.WriteLine("Opgave4:");
            Console.WriteLine("-1 + 3 * 5 = {0}", -1 + 3 * 5f);
            Console.WriteLine("(24 + 5) % 7 = {0}", (24 + 5) % 7f);
            Console.WriteLine("15 + -4 * 6 / 11 = {0}", 15 + -4 * 6 / 11f);
            Console.WriteLine("2 + 10 / 6 * 1 - 7 % 2 = {0}", 2 + 10 / 6 * 1 - 7 % 2f);
            Console.ReadKey();
            Console.WriteLine("");
        }

        static void Opgave5()
        // Write a program to print the result of multiplying two numbers which will be entered by the user
        {
            Console.WriteLine("Opgave5:");
            int X, Y;
            Console.Write("Indtast et tal: ");
            String S = Console.ReadLine();
            if (S == "") {
                X = 0;
            }
            else
            {
                X = Convert.ToInt32(S);
            }
            Console.Write("Indtast et andet tal: ");
            S = Console.ReadLine();
            Y = Convert.ToInt32(S);
            Console.WriteLine("{0} X {1} = {2}", X, Y, X * Y);
            Console.ReadKey();
            Console.WriteLine("");
        }

        static void Opgave6()
        // Write a program to print the result

        {
            Console.WriteLine("Opgave6:");
            Console.ReadKey();
            Console.WriteLine("");
        }

        static void Opgave7()
        // Write a program to print the result
        {
            Console.WriteLine("Opgave7:");
            Console.ReadKey();
            Console.WriteLine("");
        }


    }
}
