﻿namespace Phoneword
{
    public interface IDialer
    {
        bool Dial(string number);
    }
}
