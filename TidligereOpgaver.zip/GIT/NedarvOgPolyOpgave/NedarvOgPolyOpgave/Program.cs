﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NedarvOgPolyOpgave
{
    class Program
    {
        public abstract class Expression
        {
            public abstract double Evaluate();
        }

        public sealed class ConstantExpression : Expression
        {
            // Felter
            private readonly double value;
            // Constructor
            public ConstantExpression(double value)
            {
                this.value = value;
            }
            // Metoder
            public override double Evaluate()
            {
                return value;
            }
            public override string ToString()  // Override System.ToString
            {
                return value.ToString();
            }
        }
        
        public abstract class BinaryExpression : Expression
        {
            // Felter
            protected readonly Expression left;
            protected readonly Expression right;
            // Constructor
            protected BinaryExpression(Expression left, Expression right)
            {
                this.left = left;
                this.right = right;
            }
            // Property
            public abstract string OperatorSymbol { get; } 
            // Metoder
            public sealed override string ToString()
            {
                return left.ToString() + " " + OperatorSymbol + " " + right.ToString();
            }
        }

        public class PlusExpression : BinaryExpression
        {
            // Constructor
            public PlusExpression(Expression left, Expression right) : base(left, right) { }
            // Property
            public override string OperatorSymbol
            {
                get
                {
                    return "+";
                }
            }
            // Metoder
            public override double Evaluate()
            {
                return left.Evaluate() + right.Evaluate();
            }
        }

        public class MinusExpression : BinaryExpression
        {
            // Constructor
            public MinusExpression(Expression left, Expression right) : base(left, right) { }
            // Property
            public override string OperatorSymbol { get { return "-"; } }
            // Metoder
            public override double Evaluate()
            {
                return left.Evaluate() - right.Evaluate();
            }
        }

        public class MultiplyExpression : BinaryExpression
        {
            // Constructor
            public MultiplyExpression(Expression left, Expression right) : base(left, right) { }
            // Property
            public override string OperatorSymbol { get { return "*"; }  }
            // Metoder
            public override double Evaluate()
            {
                return left.Evaluate() * right.Evaluate();
            }
        }

        //public class UnaryExpression : Expression
        //{
        //    protected Expression expr;
        //}



        static void Main(string[] args)
        {
            Expression expr = new PlusExpression(
                left: new ConstantExpression(4),
                right: new PlusExpression(
                    left: new ConstantExpression(1),
                    right: new ConstantExpression(2)));


            Console.Write(expr.ToString());

            Console.Write(" = ");

            Console.WriteLine(expr.Evaluate());

            Console.ReadKey();



        }
    }
}
