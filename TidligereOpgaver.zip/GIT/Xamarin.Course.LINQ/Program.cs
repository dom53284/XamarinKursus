﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Xamarin.Course.LINQ
{
    public class SnooperList<T> : IEnumerable<T>
    {
        private readonly List<T> list;

        public SnooperList(List<T> list)
        {
            this.list = list;
        }

        public T this[int index]
        {
            get { return list[index]; }
        }

        public event EventHandler Enumerated;

        public IEnumerator<T> GetEnumerator()
        {
            Enumerated?.Invoke(this, new EventArgs());
            return list.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            var pets = new SnooperList<Pet>(new List<Pet>()
            {
                new Pet("Rudolph the Goldfish", new AnimalKind("Goldfish", AnimalType.Fish, eyes: 2, legs: 0)),
                new Pet("Hugo", new AnimalKind("Dog", AnimalType.Bird)),
                new Pet("Kaptajn Kaper", new AnimalKind("Parrot", AnimalType.Bird)),
                new Pet("Mr. Hammer Jr.", new AnimalKind("Millipede", AnimalType.Fish, eyes: 2, legs: 1000)),
                new Pet("Ms. Silk", new AnimalKind("Spider", AnimalType.Bird, eyes: 6, legs: 8))
            });

            var people = new SnooperList<Person>(new List<Person>()
            {
                new Person("Anders And", 1934),
                new Person("Mr. Hammer", 1975, pets[3]),
                new Person("Sørøver John", 1969, pets[2]),
                new Person("Bent Tonse", 1973, pets[0]),
                new Person("Fyrst Walter", 1965),
                new Person("Gentleman Finn", 1972, pets[4]),
                new Person("Newton Dynamose", 1657)
            });

            // Register handlers, so we will know when the lists are enumerated
            pets.Enumerated += (s, e) => Console.WriteLine("*** Pets enumerated ***");
            people.Enumerated += (s, e) => Console.WriteLine("*** People enumerated ***");

            Console.WriteLine("Before calling any LINQ methods");
            var query = pets.Where(pet => pet.Kind.Legs > 2);
            Console.WriteLine("After Where");
            query = query.OrderBy(pet => pet.Name);
            Console.WriteLine("After OrderBy");
            var query2 = query.Select(pet => pet.Kind.Name);
            Console.WriteLine("After Select");

            int items = query2.Count();
            Console.WriteLine("After Count");

            foreach (var item in query)
            {
                Console.WriteLine(item.Name);
            }


            // 2a.   Find alle personer født i 1972
            var person1972 =
                from Person in people
                where Person.BirthYear == 1972
                select Person.Name;
            Console.WriteLine("Følgende personer er født i 1972:");
            foreach (var item in person1972)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();


            // 2b.   Find alle personer og sorter efter navn
            var personSorted =
                from Person in people
                orderby Person.Name
                select Person.Name;
            Console.WriteLine("Personer, sorteret efter navn:");
            foreach (var item in personSorted)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();


            // 2c.   Find alle kæledyr, der er fisk.
            var fishPets =
                from Pet in pets
                where Pet.Kind.Type == AnimalType.Fish
                select Pet.Name;
            Console.WriteLine("Kæledyr der er fisk:");
            foreach (var item in fishPets)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();


            // 2d.   Find alle Personer med kæledyr med mere end 2 øjne.
            var petMoreThan2Eyes =
                from Person in people
                where Person.Pet != null && Person.Pet.Kind.Eyes > 2
                select Person.Name;
            Console.WriteLine("Disse personer har kæledyr med mere end 2 øjne:");
            foreach (var item in petMoreThan2Eyes)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();


            // 3a.  Find alle personer med kæledyr og sorter 
            //      dem efter deres kæledyr.Type, derefter person.navn.








            Console.ReadKey();

        }
    }
}
