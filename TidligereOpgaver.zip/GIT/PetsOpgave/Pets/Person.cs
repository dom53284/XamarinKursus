﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetsOpgave
{
    // Lav en delegate Filter, der tager en person som input og returnerer en bool
    public delegate bool Filter(Person person);

    // Lav en statisk PersonExtensions klasse:
    // a. Med en extension metode FilterOut for
    //    List<Person>, der giver et Filter - løber igennem
    //    listen og kun returnerer de elementer, hvorpå Filter
    //    returnerer false.
    public static class PersonExtensions
    {
        public static List<Person> FilterOut(this List<Person> pliste, Filter dfilter)
        {
            var newPListe = new List<Person>();

            foreach (var item in pliste)
            {
                if (!dfilter.Invoke(item))
                {
                    newPListe.Add(item);
                }
            }

            return newPListe;
        }
    }

    public class Person : INotifyPropertyChanged
    {

        private string name;
        private int birthyear;
        private Pet pet;

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                if (Name != value)
                {
                    this.name = value;
                    OnNameChanged();
                    //NameChanged?.Invoke(this, this.name); // alternativ
                    //OnPropertyChanged("Name");
                    OnPropertyChanged(nameof(Name));
                }
            }
        }

        public int BirthYear
        {
            get
            {
                return birthyear;
            }
        }

        public Pet Pet
        {
            get
            {
                return pet;
            }
        }

        public string GetName()
        {
            return this.Name;
        }

        public int GetAge()
        {
            return DateTime.Now.Year - this.BirthYear;
        }

        public int GetNumberOfEyes()
        {
            return this.Pet.Specie.NumberOfEyes;
        }

        public Person(String name, int birthyear, Pet pet)
        {
            this.name = name;
            this.pet = pet;
            this.birthyear = birthyear;
        }

        public Person(String name)
        {
            this.name = name;
        }

        public Person(String name, Pet pet)
        {
            this.name = name;
            this.pet = pet;
        }

        public Person(String name, String petName, Species specie)
        {
            this.name = name;
            var p = new Pet(specie, petName);
            this.pet = p;
        }

        public event EventHandler<string> NameChanged;
        public event PropertyChangedEventHandler PropertyChanged;

        private void OnNameChanged()
        {
            EventHandler<string> handler = NameChanged;
            if (handler != null)
            {
                handler(this, this.Name);
            }
        }

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            // Den 'Gamle' måde
            // var handler = PropertyChanged;
            // if (handler != null)
            // {
            //     handler.Invoke(this, new PropertyChangedEventArgs(propertyName));
            // ELLER handler(this, new PropertyChangedEventArgs(propertyName));
            // }
        }

    }
}
