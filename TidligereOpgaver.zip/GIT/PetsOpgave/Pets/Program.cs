﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetsOpgave
{
    class Observer
    {
        public void HandleEvent(object sender, string newName)
        {
            Console.WriteLine("Navnet er ændret: " + newName);
        }
        public void PropertyChangedEventHandler(object sender, string propName)
        {
            Console.WriteLine("Property er ændret: " + propName);
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            Species elefant = new Species("Elefant", 2, 4, AnimalTypeEnum.Bird);
            Species tiger = new Species("HandikappetTiger", 1, 4, AnimalTypeEnum.Fish);
            Species duck = new Species("And", 3, 2, AnimalTypeEnum.Fish);

            Pet karlspet = new Pet(elefant, "Rufus");
            Person karl = new Person("Karl", 1920, karlspet);


            //Console.WriteLine(karl.Name);

            //Console.WriteLine(karl.GetName());
            //Console.WriteLine(karl.GetAge());
            //Console.WriteLine(karl.GetNumberOfEyes());

            //Observer nch = new Observer();

            //karl.NameChanged += nch.HandleEvent;
            
            //karl.Name = "Nyt navn";
            //Console.WriteLine( karl.Pet.Specie.Talk());




            // 4.  Lav en liste af personer og filtrer alle personer der:
            //     a.  Har et kæledyr med flere end 2 øjne.
            //     b.  Hedder "Egon".
            Console.WriteLine("Extension method");

            var person1 = new Person("Brian", "2 øjet", elefant);
            var person2 = new Person("Ib", "1 øjet", tiger);
            var person3 = new Person("Egon", "2 øjet", elefant);
            var person4 = new Person("Klaus", "2 øjet", elefant);
            var person5 = new Person("Tom", "3 øjet", duck);

            List<Person> PListe = new List<Person>();

            PListe.Add(person1);
            PListe.Add(person2);
            PListe.Add(person3);
            PListe.Add(person4);
            PListe.Add(person5);

            List<Person> PListe2 = PListe.FilterOut(u => u.Pet.Specie.NumberOfEyes <= 2);

            Console.WriteLine();
            Console.WriteLine("Liste på personer med kæledyr med mere end 2 øjne:");
            foreach (var item in PListe2)
            {
                Console.WriteLine(item.Name);
            }

            List<Person> PListe3 = PListe.FilterOut(u => u.Name != "Egon");

            Console.WriteLine();
            Console.WriteLine("Liste på personer der hedder 'Egon':");
            foreach (var item in PListe3)
            {
                Console.WriteLine(item.Name);
            }

            Console.ReadKey();






        }
    }

    public class Usage
    {

    }

}
