﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetsOpgave
{
    public class Pet
    {
        private Species specie;
        private string name;

        public Species Specie
        {
            get
            {
                return specie;
            }
        }

        public string Name
        {
            get
            {
                return name;
            }
        }

        public Pet(Species specie, string name)
        {
            this.specie = specie;
            this.name = name;
        }
    }
}
