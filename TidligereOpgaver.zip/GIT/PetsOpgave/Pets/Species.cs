﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetsOpgave
{
    public enum AnimalTypeEnum { Bird, Fish };

    public class Species
    {
        private string name;
        private int numberofeyes;
        private int numberoflegs;
        private AnimalTypeEnum animalType = AnimalTypeEnum.Fish;

        public AnimalTypeEnum AnimalType
        {
            get
            {
                return animalType;
            }
        }

        public string Name
        {
            get
            {
                return Name;
            }
        }

        public int NumberOfEyes
        {
            get
            {
                return numberofeyes;
            }
        }

        public int NumberOfLegs
        {
            get
            {
                return numberoflegs;
            }
        }

        public Species(string name, int numberofeyes, int numberoflegs, AnimalTypeEnum animalType)
        {
            this.name = name;
            this.numberofeyes = numberofeyes;
            this.numberoflegs = numberoflegs;
            this.animalType = animalType;
        }

        public Species(string name, int numberoflegs) : this(name, 2, numberoflegs, AnimalTypeEnum.Fish) { }

        public static List<Species> CreateFarm()
        {
            var specie = new List<Species>();
            specie.Add(new Species("Tom", 4));

            return specie;
        }

        public string Talk()
        {
            switch (this.animalType)
            {
                case AnimalTypeEnum.Bird:
                    return "Pip pip!";
                case AnimalTypeEnum.Fish:
                    return "...";
                default:
                    return "intet dyr";  
            }            

            //if(this.animalType == AnimalTypeEnum.Bird)
            //{
            //    return "Pip pip!";
            //}
            //else
            //{
            //    return "...";
            //}

        }


    }


}
